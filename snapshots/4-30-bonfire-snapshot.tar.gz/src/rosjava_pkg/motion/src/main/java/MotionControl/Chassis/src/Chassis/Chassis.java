package Chassis;

//import MotorControlSolution.*;
import MotorControl.*;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/**
 * <p>
 * Entry point for chassis lab.
 * </p>
 **/
public class Chassis {

    /**
     * <p>
     * The robot.
     * </p>
     **/
    public static OdometryRobot robot = new OdometryRobot();

    /**
     * <p>
     * Entry point for the chassis lab.
     * </p>
     * 
     * @param args
     *            command line arguments
     **/
    public static void main(String[] args) {

        // ////////////////// create velocity controller //////////////////////

        RobotVelocityController robotVelocityController = new RobotVelocityControllerBalanced();

        robot.setRobotVelocityController(robotVelocityController);

        // ////////////////// create position controller /////////////////////

        RobotPositionController robotPositionController = new RobotPositionController(
                robot);

        robot.setRobotPositionController(robotPositionController);

        // ////////////////// config controllers /////////////////////////////

        // if your velocity and/or position controllers need to be configured
        // (i.e. gains set, etc), then do it here

        // this block to configures *our* solution to lab 2 (yours may or
        // may not be configured the same way)
        final double VELOCITY_BALANCE_GAIN = 1.0;
        final double VELOCITY_WHEEL_GAIN = 10.0;
        robotVelocityController.setGain(VELOCITY_BALANCE_GAIN);
        robotVelocityController.getWheelVelocityController(RobotBase.LEFT)
                .setGain(VELOCITY_WHEEL_GAIN);
        robotVelocityController.getWheelVelocityController(RobotBase.RIGHT)
                .setGain(VELOCITY_WHEEL_GAIN);

        // ////////////////// display estop button //////////////////////////

        EstopButton estop = new EstopButton(Thread.currentThread());

        // ////////////////// command motion ////////////////////////////////

        // Begin Student Code
        robot.enableMotors(true);
	/* SQUARE
        robot.robotPositionController.translate(5, 1);
        robot.robotPositionController.rotate(5,  Math.PI/2);
	robot.robotPositionController.translate(5, 1);
        robot.robotPositionController.rotate(5,  Math.PI/2);
	robot.robotPositionController.translate(5, 1);
        robot.robotPositionController.rotate(5,  Math.PI/2);
	robot.robotPositionController.translate(5, 1);
        robot.robotPositionController.rotate(5,  Math.PI/2);
	*/
	
	/* Out and back */
	robot.robotPositionController.translate(10, 1);
	robot.robotPositionController.rotate(10, Math.PI);
	robot.robotPositionController.translate(10, 1);
	robot.robotPositionController.rotate(10, Math.PI);
	
	//robot.robotPositionController.rotate(1, -Math.PI/2);
        // ////////////////// shutdown //////////////////////////////////////

        // robot should already be stopped, but just in case
        robot.estop();
        System.exit(0);
    }

    /**
     * <p>
     * The estop button.
     * </p>
     **/
    protected static class EstopButton extends JDialog {

        EstopButton(final Thread mainThread) {

            JButton eb = new JButton("ESTOP");
            eb.setBackground(Color.RED);
            eb.setPreferredSize(new Dimension(200, 200));
            eb.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    mainThread.interrupt();
                    robot.estop();
                    System.exit(-1);
                }
            });

            setContentPane(eb);
            setTitle("Emergency Stop");
            setDefaultCloseOperation(JDialog.DO_NOTHING_ON_CLOSE);
            pack();
            setVisible(true);
        }
    }
}
