package orc;

public interface OrcListener
{
    void orcStatus(Orc p0, long p1, OrcStatus p2);
}
